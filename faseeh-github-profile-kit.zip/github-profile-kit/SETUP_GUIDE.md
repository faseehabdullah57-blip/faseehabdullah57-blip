# GitHub Profile Implementation Kit

This kit contains three files for the profile repository:
- `README.md` — the new engineering-first profile page.
- `scripts/update_profile.py` — retrieves published releases and the latest default-branch commit from five selected public repositories.
- `.github/workflows/update-profile.yml` — runs the updater daily, on demand, and after relevant profile-repository changes.

## Part 1 — Open the correct repository

1. Sign in to GitHub in your desktop browser.
2. Open https://github.com/faseehabdullah57-blip/faseehabdullah57-blip
3. Confirm the repository name is exactly `faseehabdullah57-blip`.
4. Confirm the branch selector shows `main`.

This is the special profile repository. Its README is displayed on your GitHub profile.

## Part 2 — Replace README.md

1. Open `README.md`.
2. Click the pencil icon (Edit this file).
3. Select all existing text in the editor and replace it with the contents of this kit's `README.md`.
4. Click **Commit changes**.
5. Use the message: `feat(profile): establish evidence-led engineering hub`.
6. Commit directly to `main` for this simple single-user setup.

## Part 3 — Add the Python updater

1. Return to the repository home page.
2. Click **Add file** → **Create new file**.
3. Enter this path in the filename field: `scripts/update_profile.py`
4. Paste the complete contents of this kit's `scripts/update_profile.py`.
5. Commit with message: `feat(profile): add dynamic activity and release updater`.

GitHub creates the `scripts` directory automatically when you use a slash in the filename.

## Part 4 — Add the GitHub Actions workflow

1. Return to the repository home page.
2. Click **Add file** → **Create new file**.
3. Enter this path: `.github/workflows/update-profile.yml`
4. Paste the complete contents of this kit's `.github/workflows/update-profile.yml`.
5. Commit with message: `ci(profile): automate README updates`.

GitHub creates the hidden `.github/workflows` directories automatically.

## Part 5 — Enable workflow write permission

1. In the profile repository, open **Settings**.
2. In the left sidebar, open **Actions** → **General**.
3. Find **Workflow permissions**.
4. Select **Read and write permissions**.
5. Click **Save**.

The workflow also declares `permissions: contents: write`. Repository settings must permit the workflow token to use that permission.

## Part 6 — Run and verify

1. Open the repository's **Actions** tab.
2. Select **Update profile README** in the workflow list.
3. Click **Run workflow** → choose `main` → **Run workflow**.
4. Open the run and inspect each step.
5. A green check means the workflow completed successfully.
6. Return to the profile README and verify the Recent releases and Recent repository updates sections.

The schedule is `23 6 * * *` UTC (11:23 AM Pakistan Standard Time). GitHub scheduled runs can be delayed during busy periods.

## What the updater does — and does not do

- It checks the five listed public repositories.
- It lists up to five latest published releases across them.
- It lists each repository's latest commit on its default branch.
- It does not claim those commits were authored by you.
- It does not invent releases when none exist.
- It does not modify any of the five project repositories.
- It does not publish contribution counts, stars, followers, languages, or test coverage as achievements.

## If the workflow fails

- **403 / Resource not accessible:** verify Actions workflow permissions are set to Read and write.
- **Workflow not found:** confirm the file path is exactly `.github/workflows/update-profile.yml` and it has been committed to `main`.
- **Python/API failure:** open the failed run, expand the failing step, and inspect the error. Do not hide API failures; the script intentionally fails rather than presenting stale generated data as current.
- **No releases:** this is normal until a repository has a published GitHub Release.

## Important

The connected GitHub integration in the previous attempt returned HTTP 403 for a contents write. Editing while signed into GitHub's website uses your own browser session and is a separate route. Do not create a personal access token just to run this workflow; the built-in `GITHUB_TOKEN` is sufficient for the public repositories listed here.
