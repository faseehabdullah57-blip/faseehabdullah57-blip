#!/usr/bin/env python3
"""Update generated release and latest-commit sections in the profile README.

The script uses only the Python standard library and the GitHub Actions token.
It lists the latest commit on each selected repository's default branch; it
does not imply that the commit was authored by the profile owner.
"""
from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

OWNER = "faseehabdullah57-blip"
REPOSITORIES = [
    "ghl-data-migration-tool",
    "ghl-lead-scoring-service",
    "ghl-webhook-processor.",
    "ghl-snapshot-validator",
    "leadflow-crm",
]
API = "https://api.github.com"
README = "README.md"


def api_get(path: str) -> object:
    token = os.environ.get("GITHUB_TOKEN", "")
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "profile-readme-updater",
    }
    if token:
        headers["Authorization"] = "Bearer " + token
    request = urllib.request.Request(API + path, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        raise RuntimeError(
            f"GitHub API HTTP {exc.code} for {path}: {detail}"
        ) from exc


def encoded_repo(repo: str) -> str:
    return urllib.parse.quote(repo, safe="")


def latest_release(repo: str) -> dict | None:
    releases = api_get(
        f"/repos/{OWNER}/{encoded_repo(repo)}/releases?per_page=5"
    )
    if not isinstance(releases, list):
        raise RuntimeError(f"Unexpected releases response for {repo}")
    published = [
        item for item in releases
        if item.get("published_at") and not item.get("draft")
    ]
    return published[0] if published else None


def latest_commit(repo: str) -> dict:
    commits = api_get(
        f"/repos/{OWNER}/{encoded_repo(repo)}/commits?per_page=1"
    )
    if not isinstance(commits, list) or not commits:
        raise RuntimeError(f"No commit data returned for {repo}")
    return commits[0]


def replace_section(text: str, name: str, body: str) -> str:
    start = f"<!-- {name}:start -->"
    end = f"<!-- {name}:end -->"
    pattern = re.compile(re.escape(start) + r".*?" + re.escape(end), re.DOTALL)
    replacement = f"{start}\n{body.strip()}\n{end}"
    updated, count = pattern.subn(lambda _: replacement, text, count=1)
    if count != 1:
        raise RuntimeError(f"Could not find exactly one marker pair for {name}")
    return updated


def main() -> int:
    workspace = os.environ.get("GITHUB_WORKSPACE", ".")
    readme_path = os.path.join(workspace, README)
    with open(readme_path, encoding="utf-8") as handle:
        readme = handle.read()

    releases = []
    activity = []

    for repo in REPOSITORIES:
        release = latest_release(repo)
        if release:
            releases.append((release.get("published_at", ""), repo, release))

        commit = latest_commit(repo)
        commit_data = commit.get("commit", {})
        author = commit_data.get("author") or {}
        message = (commit_data.get("message") or "Commit").splitlines()[0]
        activity.append({
            "date": author.get("date", ""),
            "repo": repo,
            "sha": commit.get("sha", "")[:7],
            "message": message,
            "url": commit.get(
                "html_url",
                f"https://github.com/{OWNER}/{repo}/commits",
            ),
        })

    releases.sort(key=lambda item: item[0], reverse=True)
    activity.sort(key=lambda item: item["date"], reverse=True)

    release_lines = []
    for published, repo, release in releases[:5]:
        date = datetime.fromisoformat(
            published.replace("Z", "+00:00")
        ).date().isoformat()
        title = release.get("name") or release.get("tag_name") or "Release"
        url = release.get(
            "html_url",
            f"https://github.com/{OWNER}/{repo}/releases",
        )
        release_lines.append(f"- [{repo} — {title}]({url}) · {date}")

    release_body = (
        "\n".join(release_lines)
        if release_lines
        else "_No published GitHub releases found for the featured repositories yet._"
    )

    activity_lines = []
    for item in activity[:5]:
        date = item["date"][:10] if item["date"] else "Date unavailable"
        message = item["message"].replace("[", r"\[").replace("]", r"\]")
        activity_lines.append(
            f"- [{item['repo']}]({item['url']}) · {date} · "
            f"{message} (`{item['sha']}`)"
        )

    activity_body = (
        "\n".join(activity_lines)
        if activity_lines
        else "_No recent repository updates available._"
    )

    readme = replace_section(readme, "recent-releases", release_body)
    readme = replace_section(readme, "recent-activity", activity_body)

    with open(readme_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(readme)

    print("Profile README dynamic sections updated.")
    print(f"Published releases found: {len(releases)}")
    print(f"Repositories checked: {len(REPOSITORIES)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"Profile update failed: {error}", file=sys.stderr)
        raise SystemExit(1)
